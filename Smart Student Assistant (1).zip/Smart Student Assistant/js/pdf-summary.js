/* =============================================
   pdf-summary.js – PDF Summary Feature
   CampusGenius AI
   Uses PDF.js (CDN) for client-side text extraction
   ============================================= */

'use strict';

// ── Load PDF.js from CDN dynamically ──────────────────────
(function loadPDFJS() {
  const script = document.createElement('script');
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
  script.onload = () => {
    window.pdfjsLib.GlobalWorkerOptions.workerSrc =
      'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  };
  document.head.appendChild(script);
})();

// ── DOM refs ──────────────────────────────────────────────
const uploadZone    = document.getElementById('pdf-upload-zone');
const fileInput     = document.getElementById('pdf-file-input');
const fileInfo      = document.getElementById('pdf-file-info');
const filename      = document.getElementById('pdf-filename');
const infoText      = document.getElementById('pdf-info-text');
const analyzeBtn    = document.getElementById('pdf-analyze-btn');
const resultsDiv    = document.getElementById('pdf-results');

let extractedText   = '';

// ── Drag & Drop ───────────────────────────────────────────
uploadZone?.addEventListener('dragover', e => {
  e.preventDefault();
  uploadZone.classList.add('drag-over');
});

uploadZone?.addEventListener('dragleave', () => {
  uploadZone.classList.remove('drag-over');
});

uploadZone?.addEventListener('drop', e => {
  e.preventDefault();
  uploadZone.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file && file.type === 'application/pdf') handleFile(file);
  else window.showToast?.('Please drop a PDF file.', 'error');
});

fileInput?.addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) handleFile(file);
});

// ── Handle File ───────────────────────────────────────────
async function handleFile(file) {
  uploadZone.style.display = 'none';
  fileInfo.style.display   = 'block';
  resultsDiv.style.display = 'none';
  resultsDiv.innerHTML     = '';

  filename.textContent     = file.name;
  infoText.textContent     = 'Extracting text from PDF...';
  analyzeBtn.disabled      = true;
  analyzeBtn.innerHTML     = '<span class="spinner" style="width:16px;height:16px;"></span> Extracting...';

  try {
    extractedText = await extractPDFText(file);
    const wordCount = extractedText.split(/\s+/).length;
    infoText.textContent = `✅ Extracted ~${wordCount.toLocaleString()} words`;

    analyzeBtn.disabled = false;
    analyzeBtn.innerHTML = '🤖 Analyze with AI';

  } catch (err) {
    infoText.textContent = `❌ Failed to read PDF: ${err.message}`;
    window.showToast?.('Could not read this PDF. Try another file.', 'error');
  }
}

// ── Extract Text from PDF ────────────────────────────────
async function extractPDFText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async function (e) {
      try {
        if (!window.pdfjsLib) throw new Error('PDF.js not loaded yet. Please wait a moment.');

        const typedArray = new Uint8Array(e.target.result);
        const pdf = await window.pdfjsLib.getDocument({ data: typedArray }).promise;

        let fullText = '';
        const maxPages = Math.min(pdf.numPages, 60); // Cap at 60 pages

        for (let i = 1; i <= maxPages; i++) {
          const page    = await pdf.getPage(i);
          const content = await page.getTextContent();
          const text    = content.items.map(item => item.str).join(' ');
          fullText     += text + '\n';
        }

        if (!fullText.trim()) throw new Error('No readable text found in this PDF.');
        resolve(fullText.trim());
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('File read failed.'));
    reader.readAsArrayBuffer(file);
  });
}

// ── Analyze Button ────────────────────────────────────────
analyzeBtn?.addEventListener('click', async () => {
  if (!extractedText) return;

  analyzeBtn.disabled  = true;
  analyzeBtn.innerHTML = '<span class="spinner" style="width:16px;height:16px;"></span> Analyzing...';
  resultsDiv.style.display = 'none';
  resultsDiv.innerHTML = '';

  const truncated = extractedText.slice(0, 12000); // Limit tokens

  const prompt = `You are an expert academic assistant. Analyze the following document text and provide:

1. **SUMMARY** – A clear, concise 150-200 word summary of the entire content.
2. **KEY POINTS** – 8-10 most important points as bullet points.
3. **FREQUENTLY ASKED QUESTIONS** – 5 likely FAQs with answers based on this content.
4. **IMPORTANT EXAM QUESTIONS** – 8 possible exam questions with brief answers.

Document Text:
---
${truncated}
---

Format your response with clear section headers.`;

  try {
    const response = await window.askAI(prompt);
    displayResults(response);
    window.showToast?.('PDF analyzed successfully!', 'success');
  } catch (err) {
    window.showToast?.(err.message, 'error');
    infoText.textContent = `❌ Analysis failed: ${err.message}`;
  } finally {
    analyzeBtn.disabled  = false;
    analyzeBtn.innerHTML = '🔄 Re-Analyze';
  }
});

// ── Display Results ───────────────────────────────────────
function displayResults(text) {
  resultsDiv.style.display = 'flex';

  const sections = [
    { key: 'SUMMARY',                    icon: '📋', title: 'Summary' },
    { key: 'KEY POINTS',                  icon: '🔑', title: 'Key Points' },
    { key: 'FREQUENTLY ASKED QUESTIONS',  icon: '❓', title: 'Frequently Asked Questions' },
    { key: 'IMPORTANT EXAM QUESTIONS',    icon: '📝', title: 'Important Exam Questions' },
  ];

  // Try to parse sections
  sections.forEach((section, idx) => {
    const regex = new RegExp(
      `(?:${section.key}|${section.title.toUpperCase()})[^\n]*\n([\s\S]*?)(?=\\n(?:SUMMARY|KEY POINTS|FREQUENTLY|IMPORTANT|$))`,
      'i'
    );

    // Fallback: split the response into 4 roughly equal parts
    let content = '';
    const match = text.match(regex);
    if (match) {
      content = match[1].trim();
    } else {
      const lines = text.split('\n').filter(l => l.trim());
      const chunk = Math.ceil(lines.length / 4);
      content = lines.slice(idx * chunk, (idx + 1) * chunk).join('\n');
    }

    const card = document.createElement('div');
    card.className = 'result-card fade-in';
    card.innerHTML = `
      <div class="result-card-header">
        <span style="font-size:1.3rem;">${section.icon}</span>
        <h3>${section.title}</h3>
      </div>
      <div class="result-content">${window.formatAIResponse(content)}</div>
    `;
    resultsDiv.appendChild(card);
  });

  resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
