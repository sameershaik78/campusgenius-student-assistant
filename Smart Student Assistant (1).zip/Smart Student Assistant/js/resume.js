/* =============================================
   resume.js – Resume Builder Feature
   CampusGenius AI
   ============================================= */

'use strict';

const resGenerateBtn = document.getElementById('res-generate-btn');
const resPrintBtn    = document.getElementById('res-print-btn');
const resumeDocument = document.getElementById('resume-document');

// ── Live Preview (name only) ──────────────────────────────
document.getElementById('res-name')?.addEventListener('input', function () {
  updatePreviewName(this.value);
});

function updatePreviewName(name) {
  const nameEl = resumeDocument?.querySelector('.resume-doc-name');
  if (nameEl) nameEl.textContent = name || 'Your Name';
}

// ── Generate Button ───────────────────────────────────────
resGenerateBtn?.addEventListener('click', generateResume);

async function generateResume() {
  const name    = document.getElementById('res-name')?.value.trim();
  const email   = document.getElementById('res-email')?.value.trim()   || '';
  const phone   = document.getElementById('res-phone')?.value.trim()   || '';
  const linkedin = document.getElementById('res-linkedin')?.value.trim() || '';
  const edu     = document.getElementById('res-education')?.value.trim()      || '';
  const skills  = document.getElementById('res-skills')?.value.trim()         || '';
  const projects = document.getElementById('res-projects')?.value.trim()      || '';
  const certs   = document.getElementById('res-certifications')?.value.trim() || '';
  const extra   = document.getElementById('res-extra')?.value.trim()          || '';

  if (!name) {
    window.showToast?.('Please enter your full name.', 'warning');
    document.getElementById('res-name')?.focus();
    return;
  }

  if (!edu && !skills) {
    window.showToast?.('Please add at least your education and skills.', 'warning');
    return;
  }

  resGenerateBtn.disabled  = true;
  resGenerateBtn.innerHTML = '<span class="spinner" style="width:16px;height:16px;"></span> Building Resume...';

  const prompt = `You are an expert professional resume writer. Create a polished, ATS-friendly resume for a college student.

Student Information:
- Name: ${name}
- Email: ${email || 'Not provided'}
- Phone: ${phone || 'Not provided'}
- LinkedIn/GitHub: ${linkedin || 'Not provided'}
- Education: ${edu || 'Not provided'}
- Skills: ${skills || 'Not provided'}
- Projects: ${projects || 'Not provided'}
- Certifications: ${certs || 'Not provided'}
- Extracurriculars/Achievements: ${extra || 'Not provided'}

Create a professional resume with these EXACT sections in order:
1. OBJECTIVE – A compelling 2-sentence career objective
2. EDUCATION – Formatted education history
3. TECHNICAL SKILLS – Organized skill categories
4. PROJECTS – Each project with description and technologies used
5. CERTIFICATIONS – If provided
6. ACHIEVEMENTS & EXTRACURRICULARS – If provided

Return ONLY a JSON object with this structure (no markdown, pure JSON):
{
  "objective": "text",
  "education": ["line1", "line2"],
  "skills": {"category1": ["skill1", "skill2"], "category2": ["skill3"]},
  "projects": [{"name": "...", "tech": "...", "desc": "..."}],
  "certifications": ["cert1", "cert2"],
  "achievements": ["item1", "item2"]
}`;

  try {
    const response = await window.askAI(prompt);
    let parsed;

    try {
      // Try to extract JSON from response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      parsed = JSON.parse(jsonMatch ? jsonMatch[0] : response);
    } catch {
      // Fallback: render raw
      parsed = null;
    }

    if (parsed) {
      renderResumeFromJSON(parsed, { name, email, phone, linkedin });
    } else {
      renderResumeFallback(response, { name, email, phone, linkedin });
    }

    resPrintBtn.style.display = 'inline-flex';
    window.showToast?.('Resume generated successfully!', 'success');

  } catch (err) {
    window.showToast?.(err.message, 'error');
    resumeDocument.innerHTML = `<div style="color:#ef4444;padding:20px;">❌ ${err.message}</div>`;
  } finally {
    resGenerateBtn.disabled  = false;
    resGenerateBtn.innerHTML = '✨ Generate Resume with AI';
  }
}

// ── Render Resume from Parsed JSON ───────────────────────
function renderResumeFromJSON(data, contact) {
  const { name, email, phone, linkedin } = contact;

  const contactLine = [email, phone, linkedin].filter(Boolean).join(' · ');

  let html = `
    <div class="resume-doc-header">
      <div class="resume-doc-name">${name}</div>
      <div class="resume-doc-contact">${contactLine}</div>
    </div>
  `;

  // Objective
  if (data.objective) {
    html += `
      <div class="resume-doc-section">
        <div class="resume-doc-section-title">Objective</div>
        <p>${data.objective}</p>
      </div>
    `;
  }

  // Education
  if (data.education?.length) {
    html += `
      <div class="resume-doc-section">
        <div class="resume-doc-section-title">Education</div>
        ${data.education.map(e => `<p>• ${e}</p>`).join('')}
      </div>
    `;
  }

  // Skills
  if (data.skills && Object.keys(data.skills).length) {
    html += `<div class="resume-doc-section"><div class="resume-doc-section-title">Technical Skills</div>`;
    for (const [cat, list] of Object.entries(data.skills)) {
      if (Array.isArray(list) && list.length) {
        html += `<p><strong>${cat}:</strong> ${list.join(', ')}</p>`;
      }
    }
    html += `</div>`;
  }

  // Projects
  if (data.projects?.length) {
    html += `<div class="resume-doc-section"><div class="resume-doc-section-title">Projects</div>`;
    data.projects.forEach(p => {
      html += `
        <div style="margin-bottom:10px;">
          <p><strong>${p.name}</strong> <span style="color:#888;font-size:0.78rem;">(${p.tech || ''})</span></p>
          <p style="font-size:0.82rem;">${p.desc || ''}</p>
        </div>
      `;
    });
    html += `</div>`;
  }

  // Certifications
  if (data.certifications?.length) {
    html += `
      <div class="resume-doc-section">
        <div class="resume-doc-section-title">Certifications</div>
        <ul>${data.certifications.map(c => `<li>${c}</li>`).join('')}</ul>
      </div>
    `;
  }

  // Achievements
  if (data.achievements?.length) {
    html += `
      <div class="resume-doc-section">
        <div class="resume-doc-section-title">Achievements & Extracurriculars</div>
        <ul>${data.achievements.map(a => `<li>${a}</li>`).join('')}</ul>
      </div>
    `;
  }

  resumeDocument.innerHTML = html;
}

// ── Fallback Resume Renderer ──────────────────────────────
function renderResumeFallback(text, contact) {
  const { name, email, phone, linkedin } = contact;
  const contactLine = [email, phone, linkedin].filter(Boolean).join(' · ');

  resumeDocument.innerHTML = `
    <div class="resume-doc-header">
      <div class="resume-doc-name">${name}</div>
      <div class="resume-doc-contact">${contactLine}</div>
    </div>
    <div style="font-size:0.82rem; line-height:1.8; color:#333; white-space:pre-wrap;">
      ${text.replace(/\*\*/g, '').replace(/#{1,3} /g, '')}
    </div>
  `;
}

// ── Print Button ──────────────────────────────────────────
resPrintBtn?.addEventListener('click', () => {
  const content = resumeDocument?.innerHTML || '';
  const name    = document.getElementById('res-name')?.value || 'Resume';

  const win = window.open('', '_blank');
  win.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>${name} – Resume</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
          font-family: 'Inter', Arial, sans-serif;
          font-size: 11pt;
          color: #1a1a2e;
          padding: 40px;
          max-width: 800px;
          margin: 0 auto;
          line-height: 1.6;
        }
        .resume-doc-header {
          border-bottom: 2px solid #4f8ef7;
          padding-bottom: 16px;
          margin-bottom: 20px;
        }
        .resume-doc-name {
          font-size: 22pt;
          font-weight: 700;
          color: #1a1a2e;
        }
        .resume-doc-contact {
          font-size: 9pt;
          color: #555;
          margin-top: 4px;
        }
        .resume-doc-section {
          margin-bottom: 16px;
        }
        .resume-doc-section-title {
          font-size: 9pt;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #4f8ef7;
          border-bottom: 1px solid #e5e7f0;
          padding-bottom: 4px;
          margin-bottom: 8px;
        }
        p { margin-bottom: 4px; color: #333; }
        ul { padding-left: 16px; }
        li { margin-bottom: 4px; color: #333; }
        strong { color: #1a1a2e; }
        @media print {
          body { padding: 20px; }
        }
      </style>
    </head>
    <body>${content}</body>
    </html>
  `);
  win.document.close();
  setTimeout(() => win.print(), 500);
});
