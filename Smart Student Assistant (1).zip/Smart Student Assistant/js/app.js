/* =============================================
   app.js – Core Logic, Navigation & AI Integration
   CampusGenius AI
   ============================================= */

'use strict';

// ── Profile ──────────────────────────────────────────────
let profile = JSON.parse(localStorage.getItem('cg_profile') || 'null');

function getApiKey() {
  return profile ? profile.apiKey : null;
}

// Redirect to login if no profile
if (!profile) {
  // Allow visiting dashboard without login for demo (just show demo mode)
  profile = { name: 'Student', email: '', college: 'Demo Mode', dept: 'General', apiKey: '' };
}

// ── Populate Sidebar Profile ──────────────────────────────
(function populateProfile() {
  const nameEl    = document.getElementById('profile-name');
  const collegeEl = document.getElementById('profile-college');
  const avatarEl  = document.getElementById('profile-avatar');

  if (nameEl)    nameEl.textContent    = profile.name || 'Student';
  if (collegeEl) collegeEl.textContent = `${profile.college || 'College'} • ${profile.dept || 'Dept'}`;
  if (avatarEl)  avatarEl.textContent  = (profile.name || 'S')[0].toUpperCase();
})();

// ── Toast Notifications ───────────────────────────────────
function showToast(msg, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${msg}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100px)';
    toast.style.transition = 'all 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ── Tab Navigation ────────────────────────────────────────
const panels = ['ask-ai', 'pdf-summary', 'viva-gen', 'exam-planner', 'attendance', 'resume'];

function switchPanel(target) {
  panels.forEach(id => {
    const panel  = document.getElementById(`panel-${id}`);
    const header = document.getElementById(`header-${id}`);
    const nav    = document.getElementById(`nav-${id}`);

    if (panel)  panel.classList.toggle('active', id === target);
    if (header) header.style.display = id === target ? 'flex' : 'none';
    if (nav)    nav.classList.toggle('active', id === target);
  });

  // Close sidebar on mobile
  closeSidebar();
}

// Init correct header display
panels.forEach(id => {
  const h = document.getElementById(`header-${id}`);
  if (h && id !== 'ask-ai') h.style.display = 'none';
});

// Nav click listeners
document.querySelectorAll('.nav-item[data-panel]').forEach(item => {
  item.addEventListener('click', () => switchPanel(item.dataset.panel));
});

// ── Mobile Sidebar ────────────────────────────────────────
const sidebar  = document.getElementById('sidebar');
const overlay  = document.getElementById('sidebar-overlay');
const hamburger = document.getElementById('hamburger-btn');

function openSidebar() {
  sidebar.classList.add('open');
  overlay.classList.add('open');
}

function closeSidebar() {
  sidebar.classList.remove('open');
  overlay.classList.remove('open');
}

hamburger?.addEventListener('click', openSidebar);
overlay?.addEventListener('click', closeSidebar);

// ── Footer Links ──────────────────────────────────────────
document.getElementById('footer-clear-link')?.addEventListener('click', e => {
  e.preventDefault();
  const msgs = document.getElementById('chat-messages');
  if (msgs) {
    // Keep only welcome message
    const welcome = msgs.querySelector('.chat-message.ai');
    msgs.innerHTML = '';
    if (welcome) msgs.appendChild(welcome);
  }
  window.chatHistory = [];
  showToast('Chat cleared!', 'info');
});

// ── Core AI Call ──────────────────────────────────────────
/**
 * Call Gemini API with a prompt.
 * @param {string} prompt     - Full prompt text
 * @param {string} [system]   - Optional system/context prefix
 * @returns {Promise<string>} - AI response text
 */
async function askAI(prompt, system = '') {
  const key = getApiKey();

  if (!key || key.length < 10) {
    showToast('No API key found. Please login and add your Gemini API key.', 'error');
    throw new Error('No API key');
  }

  const fullPrompt = system ? `${system}\n\n${prompt}` : prompt;

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: fullPrompt }] }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 4096,
        }
      })
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = err?.error?.message || `API error (${res.status})`;
    if (res.status === 400) throw new Error('Invalid API key or request. Please check your Gemini API key.');
    if (res.status === 429) throw new Error('Rate limit reached. Please wait a moment and try again.');
    throw new Error(msg);
  }

  const data = await res.json();

  if (!data.candidates || !data.candidates[0]) {
    throw new Error('No response from AI. Try again.');
  }

  return data.candidates[0].content.parts[0].text;
}

// ── Markdown-like formatter ───────────────────────────────
function formatAIResponse(text) {
  return text
    // Headers
    .replace(/^### (.+)$/gm, '<h4>$1</h4>')
    .replace(/^## (.+)$/gm, '<h3>$1</h3>')
    .replace(/^# (.+)$/gm, '<h3>$1</h3>')
    // Bold
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Code blocks
    .replace(/```[\w]*\n([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
    // Inline code
    .replace(/`(.+?)`/g, '<code style="background:rgba(79,142,247,0.1);padding:2px 6px;border-radius:4px;font-size:0.85em;">$1</code>')
    // Bullet lists
    .replace(/^\s*[-*] (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>)+/gs, '<ul>$&</ul>')
    // Numbered lists
    .replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>')
    // Paragraphs
    .replace(/\n\n/g, '</p><p>')
    .replace(/^(?!<[hup]|<li|<pre)(.+)$/gm, (m) => m.trim() ? m : '')
    // Wrap in paragraph
    .replace(/^/, '<p>')
    .replace(/$/, '</p>')
    .replace(/<p><\/p>/g, '');
}

// Expose globally
window.askAI         = askAI;
window.formatAIResponse = formatAIResponse;
window.showToast     = showToast;
window.switchPanel   = switchPanel;
