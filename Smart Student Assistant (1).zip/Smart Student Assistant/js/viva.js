/* =============================================
   viva.js – Viva Generator Feature
   CampusGenius AI
   ============================================= */

'use strict';

const vivaSubjectInput = document.getElementById('viva-subject');
const vivaGenerateBtn  = document.getElementById('viva-generate-btn');
const vivaResults      = document.getElementById('viva-results');
const vivaLoading      = document.getElementById('viva-loading');

// ── Quick-pick chips ──────────────────────────────────────
document.querySelectorAll('.viva-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    if (vivaSubjectInput) {
      vivaSubjectInput.value = chip.dataset.sub;
      generateViva();
    }
  });
});

// ── Generate Button ───────────────────────────────────────
vivaGenerateBtn?.addEventListener('click', generateViva);

vivaSubjectInput?.addEventListener('keydown', e => {
  if (e.key === 'Enter') generateViva();
});

// ── Generate Viva Questions ───────────────────────────────
async function generateViva() {
  const subject = vivaSubjectInput?.value.trim();
  if (!subject) {
    window.showToast?.('Please enter a subject name.', 'warning');
    vivaSubjectInput?.focus();
    return;
  }

  vivaResults.innerHTML    = '';
  vivaLoading.style.display = 'block';
  vivaGenerateBtn.disabled  = true;
  vivaGenerateBtn.innerHTML = '<span class="spinner" style="width:16px;height:16px;"></span> Generating...';

  const prompt = `You are an expert professor and viva examiner.
Generate exactly 20 viva voce questions and detailed answers for the subject: "${subject}".

Format your response EXACTLY as follows — each question on its own line, each answer on the next line:

Q1: [Question]
A1: [Detailed answer]

Q2: [Question]
A2: [Detailed answer]

...continue up to Q20/A20.

Make questions span: basic concepts, important definitions, working principles, applications, advantages/disadvantages, and tricky conceptual questions.
Keep answers clear, concise but complete (2-5 sentences each).`;

  try {
    const response = await window.askAI(prompt);
    renderVivaQA(response, subject);
    window.showToast?.(`20 viva questions for "${subject}" ready!`, 'success');
  } catch (err) {
    vivaResults.innerHTML = `<div style="text-align:center; padding:40px; color:var(--red);">❌ ${err.message}</div>`;
    window.showToast?.(err.message, 'error');
  } finally {
    vivaLoading.style.display = 'none';
    vivaGenerateBtn.disabled  = false;
    vivaGenerateBtn.innerHTML = '⚡ Generate';
  }
}

// ── Parse & Render Q&A Accordion ─────────────────────────
function renderVivaQA(text, subject) {
  vivaResults.innerHTML = '';

  // Header
  const header = document.createElement('div');
  header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;';
  header.innerHTML = `
    <div>
      <h3 style="font-size:1.1rem;font-weight:700;">Viva Questions: ${subject}</h3>
      <p style="font-size:0.82rem;color:var(--text-muted);margin-top:4px;">Click any question to reveal the answer</p>
    </div>
    <button class="btn btn-ghost" id="expand-all-btn" style="font-size:0.82rem;padding:8px 16px;">
      Expand All
    </button>
  `;
  vivaResults.appendChild(header);

  // Parse Q&A pairs
  const pairs = [];

  // Try structured parsing first
  const regex = /Q(\d+)[:\.)]\s*(.+?)\s*A\1[:\.)]\s*([\s\S]+?)(?=Q\d+[:\.)]|$)/gi;
  let match;

  while ((match = regex.exec(text)) !== null) {
    pairs.push({ num: match[1], q: match[2].trim(), a: match[3].trim() });
  }

  // Fallback: line-by-line parsing
  if (pairs.length < 5) {
    const lines = text.split('\n').filter(l => l.trim());
    let currentQ = null;

    lines.forEach(line => {
      const qMatch = line.match(/^Q?\s*(\d+)[:\.)]\s*(.+)/i);
      const aMatch = line.match(/^A\s*(\d+)?[:\.)]\s*(.+)/i);

      if (qMatch && !line.toLowerCase().startsWith('a')) {
        currentQ = { num: qMatch[1], q: qMatch[2], a: '' };
        pairs.push(currentQ);
      } else if (aMatch && currentQ) {
        currentQ.a = aMatch[2];
        currentQ = null;
      } else if (currentQ && !currentQ.a && line.trim()) {
        currentQ.a = line.trim();
        currentQ = null;
      }
    });
  }

  // If still no good parsing, create generic display
  if (pairs.length === 0) {
    const pre = document.createElement('div');
    pre.className = 'result-card';
    pre.style.padding = '24px';
    pre.innerHTML = `<div class="result-content">${window.formatAIResponse(text)}</div>`;
    vivaResults.appendChild(pre);
    return;
  }

  // Render accordion
  const accordion = document.createElement('div');
  accordion.className = 'qa-accordion';

  pairs.slice(0, 20).forEach((pair, idx) => {
    const item = document.createElement('div');
    item.className = 'qa-item';

    item.innerHTML = `
      <div class="qa-question">
        <div style="display:flex;align-items:center;gap:12px;flex:1;">
          <span class="qa-number">${idx + 1}</span>
          <span>${pair.q}</span>
        </div>
        <span class="qa-chevron">▼</span>
      </div>
      <div class="qa-answer">${pair.a}</div>
    `;

    item.querySelector('.qa-question').addEventListener('click', () => {
      item.classList.toggle('open');
    });

    accordion.appendChild(item);
  });

  vivaResults.appendChild(accordion);

  // Expand All button
  let allOpen = false;
  document.getElementById('expand-all-btn')?.addEventListener('click', function () {
    allOpen = !allOpen;
    accordion.querySelectorAll('.qa-item').forEach(item => {
      item.classList.toggle('open', allOpen);
    });
    this.textContent = allOpen ? 'Collapse All' : 'Expand All';
  });

  vivaResults.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
