/* =============================================
   planner.js – Exam Planner Feature
   CampusGenius AI
   ============================================= */

'use strict';

const subjectsInput   = document.getElementById('exam-subjects-input');
const subjectTags     = document.getElementById('subject-tags');
const planGenerateBtn = document.getElementById('plan-generate-btn');
const plannerLoading  = document.getElementById('planner-loading');
const plannerResults  = document.getElementById('planner-results');

let subjects = [];

// ── Subject Tag Input ─────────────────────────────────────
subjectsInput?.addEventListener('keydown', e => {
  if (e.key === 'Enter' || e.key === ',') {
    e.preventDefault();
    addSubject(subjectsInput.value.trim());
    subjectsInput.value = '';
  }
});

function addSubject(name) {
  if (!name || subjects.includes(name)) return;
  subjects.push(name);
  renderTags();
}

function removeSubject(name) {
  subjects = subjects.filter(s => s !== name);
  renderTags();
}

function renderTags() {
  subjectTags.innerHTML = '';
  subjects.forEach(s => {
    const tag = document.createElement('span');
    tag.className = 'planner-tag';
    tag.innerHTML = `${s} <button onclick="removeSubject('${s.replace(/'/g, "\\'")}')">×</button>`;
    subjectTags.appendChild(tag);
  });
}

window.removeSubject = removeSubject;

// ── Generate Study Plan ───────────────────────────────────
planGenerateBtn?.addEventListener('click', generatePlan);

async function generatePlan() {
  const days  = parseInt(document.getElementById('exam-days')?.value)  || 0;
  const hours = parseInt(document.getElementById('study-hours')?.value) || 6;
  const notes = document.getElementById('planner-notes')?.value.trim() || '';

  if (days < 1) {
    window.showToast?.('Please enter the number of days until your exam.', 'warning');
    return;
  }

  if (subjects.length === 0) {
    // Prompt to add subjects
    window.showToast?.('Please add at least one subject.', 'warning');
    subjectsInput?.focus();
    return;
  }

  plannerLoading.style.display = 'block';
  plannerResults.innerHTML     = '';
  planGenerateBtn.disabled     = true;
  planGenerateBtn.innerHTML    = '<span class="spinner" style="width:16px;height:16px;"></span> Planning...';

  const prompt = `You are an expert academic study planner for college students.

Create a detailed ${days}-day study plan for the following:
- Subjects: ${subjects.join(', ')}
- Study hours per day: ${hours} hours
- Additional notes: ${notes || 'None'}

Provide the plan in this EXACT format:

**Overall Strategy:**
[2-3 sentences on approach]

**Subject Priority:**
[Rank subjects by difficulty/importance]

**Day-by-Day Schedule:**

| Day | Date (Day X) | Subjects & Topics | Hours | Goal |
|-----|--------------|-------------------|-------|------|
[Fill all ${days} rows]

**Daily Routine Template:**
[Time slots for each study session]

**Revision Schedule:**
[Last 2 days revision plan]

**Exam Day Tips:**
[5 tips for exam day]

Make it specific, practical, and motivating. Cover all subjects proportionally.`;

  try {
    const response = await window.askAI(prompt);
    renderPlan(response, days, subjects);
    window.showToast?.('Your study plan is ready!', 'success');
  } catch (err) {
    plannerResults.innerHTML = `<div style="padding:24px; color:var(--red); text-align:center;">❌ ${err.message}</div>`;
    window.showToast?.(err.message, 'error');
  } finally {
    plannerLoading.style.display = 'none';
    planGenerateBtn.disabled     = false;
    planGenerateBtn.innerHTML    = '📅 Generate My Study Plan';
  }
}

// ── Render Study Plan ─────────────────────────────────────
function renderPlan(text, days, subs) {
  plannerResults.innerHTML = '';

  const wrapper = document.createElement('div');
  wrapper.className = 'fade-in';

  // Header card
  const headerCard = document.createElement('div');
  headerCard.className = 'result-card';
  headerCard.style.marginBottom = '20px';
  headerCard.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
      <div>
        <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:4px;">📅 Your ${days}-Day Study Plan</h3>
        <p style="font-size:0.82rem;color:var(--text-muted);">Subjects: ${subs.join(' · ')}</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button class="btn btn-ghost" id="plan-copy-btn" style="font-size:0.8rem;padding:8px 14px;">📋 Copy</button>
        <button class="btn btn-ghost" id="plan-print-btn" style="font-size:0.8rem;padding:8px 14px;">🖨️ Print</button>
      </div>
    </div>
  `;
  wrapper.appendChild(headerCard);

  // Main content card
  const contentCard = document.createElement('div');
  contentCard.className = 'result-card';
  contentCard.style.padding = '28px';

  // Convert markdown table if present
  let rendered = window.formatAIResponse(text);

  // Convert markdown tables to HTML
  rendered = rendered.replace(/\|(.+)\|/g, (fullMatch) => {
    const cells = fullMatch.split('|').filter(c => c.trim() !== '');
    return '<tr>' + cells.map(c => {
      const t = c.trim();
      return t.match(/^[-:]+$/) ? null : `<td>${t}</td>`;
    }).filter(Boolean).join('') + '</tr>';
  });

  // Wrap table rows
  if (rendered.includes('<tr>')) {
    rendered = rendered
      .replace(/(<tr>.*<\/tr>\n?)+/gs, match =>
        `<div style="overflow-x:auto;margin:16px 0;"><table class="study-plan-table">${match}</table></div>`
      );

    // Make first row a header row
    rendered = rendered.replace(/<tr>(<td>Day<\/td>|<td>.*<\/td>)/, (m) =>
      m.replace(/<td>/g, '<th>').replace(/<\/td>/g, '</th>')
    );
  }

  contentCard.innerHTML = `<div class="result-content" id="plan-content">${rendered}</div>`;
  wrapper.appendChild(contentCard);
  plannerResults.appendChild(wrapper);

  // Copy button
  document.getElementById('plan-copy-btn')?.addEventListener('click', () => {
    navigator.clipboard.writeText(text).then(() => {
      window.showToast?.('Study plan copied to clipboard!', 'success');
    });
  });

  // Print button
  document.getElementById('plan-print-btn')?.addEventListener('click', () => {
    const win = window.open('', '_blank');
    win.document.write(`
      <html><head><title>Study Plan – CampusGenius AI</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 40px; color: #333; }
        h3 { color: #4f8ef7; }
        table { width:100%; border-collapse:collapse; }
        th, td { border:1px solid #ddd; padding:8px 12px; text-align:left; }
        th { background:#f0f4ff; }
      </style></head>
      <body><h2>📅 ${days}-Day Study Plan</h2>${text.replace(/\*\*/g, '').replace(/\*/g, '')}</body></html>
    `);
    win.document.close();
    win.print();
  });

  plannerResults.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
