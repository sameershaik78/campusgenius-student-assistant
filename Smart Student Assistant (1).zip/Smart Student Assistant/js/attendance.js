/* =============================================
   attendance.js – Attendance Calculator Feature
   CampusGenius AI
   ============================================= */

'use strict';

const attCalcBtn    = document.getElementById('att-calc-btn');
const attResults    = document.getElementById('att-results');
const attEmpty      = document.getElementById('att-results-empty');
const attAIBtn      = document.getElementById('att-ai-advice-btn');
const attAIDiv      = document.getElementById('att-ai-advice');

let lastAttData = null;

// ── Calculate Button ──────────────────────────────────────
attCalcBtn?.addEventListener('click', calculateAttendance);

['att-present', 'att-absent', 'att-target'].forEach(id => {
  document.getElementById(id)?.addEventListener('keydown', e => {
    if (e.key === 'Enter') calculateAttendance();
  });
});

function calculateAttendance() {
  const present = parseInt(document.getElementById('att-present')?.value) || 0;
  const absent  = parseInt(document.getElementById('att-absent')?.value)  || 0;
  const target  = parseInt(document.getElementById('att-target')?.value)  || 75;

  if (present < 0 || absent < 0) {
    window.showToast?.('Values cannot be negative.', 'warning');
    return;
  }

  const total   = present + absent;
  if (total === 0) {
    window.showToast?.('Please enter your attendance data.', 'warning');
    return;
  }

  const pct = (present / total) * 100;

  // Classes needed to reach target
  // (present + x) / (total + x) = target/100
  // => present + x = (target/100) * (total + x)
  // => present + x = (target * total / 100) + (target * x / 100)
  // => x - (target * x / 100) = (target * total / 100) - present
  // => x * (1 - target/100) = (target * total / 100) - present
  // => x = [(target * total / 100) - present] / (1 - target/100)
  let classesNeeded = 0;
  let canMiss       = 0;

  if (pct < target) {
    const needed = ((target / 100) * total - present) / (1 - target / 100);
    classesNeeded = Math.ceil(needed);
  }

  if (pct >= target) {
    // How many more can they miss?
    // (present) / (total + x) = target/100
    // total + x = present / (target/100) = present * 100 / target
    // x = (present * 100 / target) - total
    const maxTotal = (present * 100) / target;
    canMiss = Math.floor(maxTotal - total);
    if (canMiss < 0) canMiss = 0;
  }

  lastAttData = { present, absent, total, pct, target, classesNeeded, canMiss };

  // Show results
  attEmpty.style.display   = 'none';
  attResults.style.display = 'block';

  // Animate ring
  const circumference = 2 * Math.PI * 70; // 440
  const offset = circumference - (Math.min(pct, 100) / 100) * circumference;

  const ringFill = document.getElementById('ring-fill');
  if (ringFill) {
    ringFill.style.strokeDashoffset = circumference;
    setTimeout(() => {
      ringFill.style.strokeDashoffset = offset;
    }, 100);
  }

  document.getElementById('ring-pct').textContent = pct.toFixed(1) + '%';
  document.getElementById('att-total').textContent = total;
  document.getElementById('att-pct-val').textContent = pct.toFixed(1) + '%';

  if (classesNeeded > 0) {
    document.getElementById('att-needed').textContent = classesNeeded;
    document.getElementById('att-needed').style.color = 'var(--red)';
  } else {
    document.getElementById('att-needed').textContent = '—';
    document.getElementById('att-needed').style.color = 'var(--green)';
  }

  document.getElementById('att-can-miss').textContent = canMiss > 0 ? canMiss : '0';

  // Message
  const msgDiv = document.getElementById('att-message');
  if (pct >= target) {
    const emoji = pct >= 90 ? '🌟' : pct >= 80 ? '✅' : '👍';
    msgDiv.style.background = 'rgba(16,185,129,0.1)';
    msgDiv.style.border     = '1px solid rgba(16,185,129,0.3)';
    msgDiv.style.color      = '#6ee7b7';
    msgDiv.innerHTML = `${emoji} <strong>Great!</strong> Your attendance is ${pct.toFixed(1)}% — above the ${target}% requirement. You can miss ${canMiss} more class${canMiss !== 1 ? 'es' : ''} and still be safe.`;
  } else {
    msgDiv.style.background = 'rgba(239,68,68,0.1)';
    msgDiv.style.border     = '1px solid rgba(239,68,68,0.3)';
    msgDiv.style.color      = '#fca5a5';
    msgDiv.innerHTML = `⚠️ <strong>Warning!</strong> Your attendance is ${pct.toFixed(1)}% — below the ${target}% requirement. You need to attend <strong>${classesNeeded}</strong> more consecutive class${classesNeeded !== 1 ? 'es' : ''} to reach ${target}%.`;
  }

  // Show AI advice button
  if (attAIBtn) attAIBtn.style.display = 'inline-flex';
  if (attAIDiv) attAIDiv.style.display = 'none';

  window.showToast?.('Attendance calculated!', 'success');
}

// ── AI Advice ─────────────────────────────────────────────
attAIBtn?.addEventListener('click', async () => {
  if (!lastAttData) return;

  const { present, total, pct, target, classesNeeded, canMiss } = lastAttData;

  attAIBtn.disabled  = true;
  attAIBtn.innerHTML = '<span class="spinner" style="width:16px;height:16px;"></span> Getting AI advice...';

  const prompt = `A college student has:
- Classes attended: ${present} out of ${total} total
- Current attendance: ${pct.toFixed(1)}%
- Required attendance: ${target}%
- ${pct >= target ? `They can still miss ${canMiss} classes.` : `They need to attend ${classesNeeded} more classes.`}

Give practical, encouraging advice on:
1. How to improve/maintain attendance
2. What happens if attendance is below minimum
3. Tips to communicate with professors if there's a genuine reason for absences
4. How to balance attendance with studies

Keep it brief, warm, and student-friendly.`;

  try {
    const response = await window.askAI(prompt);
    attAIDiv.style.display = 'block';
    attAIDiv.innerHTML = `
      <div class="result-card-header">
        <span style="font-size:1.2rem;">🤖</span>
        <h3 style="font-size:1rem;font-weight:700;">AI Attendance Advice</h3>
      </div>
      <div class="result-content">${window.formatAIResponse(response)}</div>
    `;
  } catch (err) {
    window.showToast?.(err.message, 'error');
  } finally {
    attAIBtn.disabled  = false;
    attAIBtn.innerHTML = '🤖 Get AI Advice on Attendance';
  }
});
