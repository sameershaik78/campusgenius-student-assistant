/* =============================================
   chat.js – Ask AI Feature
   CampusGenius AI
   ============================================= */

'use strict';

window.chatHistory = [];

const chatMessages = document.getElementById('chat-messages');
const chatInput    = document.getElementById('chat-input');
const sendBtn      = document.getElementById('send-btn');

// ── Auto-resize textarea ──────────────────────────────────
if (chatInput) {
  chatInput.addEventListener('input', function () {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 140) + 'px';
  });

  chatInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
}

sendBtn?.addEventListener('click', sendMessage);

// ── Suggestion Chips ──────────────────────────────────────
document.querySelectorAll('#chat-suggestions .suggestion-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    if (chatInput) {
      chatInput.value = chip.dataset.q;
      chatInput.style.height = 'auto';
      sendMessage();
    }
  });
});

// ── Append Message ────────────────────────────────────────
function appendMessage(role, content, isHTML = false) {
  const div = document.createElement('div');
  div.className = `chat-message ${role}`;

  const avatar = document.createElement('div');
  avatar.className = `message-avatar ${role === 'ai' ? 'ai-avatar' : 'user-avatar'}`;
  avatar.textContent = role === 'ai' ? '🤖' : (window.profile?.name?.[0]?.toUpperCase() || 'U');

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';

  if (isHTML) {
    bubble.innerHTML = content;
  } else {
    bubble.textContent = content;
  }

  div.appendChild(avatar);
  div.appendChild(bubble);
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  return div;
}

// ── Typing Indicator ──────────────────────────────────────
function showTyping() {
  const div = document.createElement('div');
  div.className = 'chat-message ai';
  div.id = 'typing-indicator';

  const avatar = document.createElement('div');
  avatar.className = 'message-avatar ai-avatar';
  avatar.textContent = '🤖';

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';

  div.appendChild(avatar);
  div.appendChild(bubble);
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function hideTyping() {
  document.getElementById('typing-indicator')?.remove();
}

// ── Send Message ──────────────────────────────────────────
async function sendMessage() {
  const text = chatInput?.value.trim();
  if (!text) return;

  // Hide suggestions after first message
  const suggestionsEl = document.getElementById('chat-suggestions');
  if (suggestionsEl) suggestionsEl.style.display = 'none';

  // Append user message
  appendMessage('user', text);
  chatInput.value = '';
  chatInput.style.height = 'auto';

  // Add to history
  window.chatHistory.push({ role: 'user', content: text });

  // Disable input while loading
  chatInput.disabled = true;
  sendBtn.disabled   = true;
  sendBtn.innerHTML  = '<span class="spinner" style="width:18px;height:18px;"></span>';

  showTyping();

  const systemPrompt = `You are CampusGenius AI, an expert academic assistant for college students. 
You help with subject explanations, concepts, problem solving, exam tips, career guidance, and more.
Keep responses well-structured, educational, and student-friendly.
Use headings, bullet points, and examples where appropriate.
The student's name is ${window.profile?.name || 'Student'}, studying ${window.profile?.dept || 'Engineering'}.`;

  try {
    const response = await window.askAI(text, systemPrompt);
    hideTyping();
    appendMessage('ai', window.formatAIResponse(response), true);
    window.chatHistory.push({ role: 'ai', content: response });
  } catch (err) {
    hideTyping();
    appendMessage('ai', `❌ Error: ${err.message}. Please check your API key in Profile settings.`, true);
    window.showToast(err.message, 'error');
  } finally {
    chatInput.disabled = false;
    sendBtn.disabled   = false;
    sendBtn.innerHTML  = '➤';
    chatInput.focus();
  }
}
