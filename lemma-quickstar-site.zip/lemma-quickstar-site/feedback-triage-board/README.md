# feedback-triage-board

A tiny Lemma starter for a product or support team.

It creates:
- a shared `feedback_items` table for incoming feedback
- a read-only `feedback-triage-agent` that classifies one row at a time
- a small HTML app named `feedback-triage-board`

## Build loop
```bash
lemma pods import ./feedback-triage-board --dry-run
lemma pods import ./feedback-triage-board
lemma apps deploy feedback-triage-board ./feedback-triage-board-app/index.html --yes
```

## Non-bundled setup
- No files or integrations are required for this starter.
- Seed a few feedback rows either through the app form or with `lemma records create`.

## Verify
```bash
lemma pods describe
lemma tables get feedback_items
lemma agents get feedback-triage-agent
```
